import React, { useState } from 'react';
import { useApp, TOOLS } from '../App';

const FOOTER_LINKS = [
  {
    title: '📝 Text Tools',
    links: [
      { label: 'Base64 Encoder/Decoder', id: 'base64' },
      { label: 'URL Encoder/Decoder', id: 'url-encode' },
      { label: 'HTML Entity Encoder', id: 'html-entity' },
      { label: 'JWT Decoder', id: 'jwt-decoder' },
      { label: 'Word Counter', id: 'word-counter' },
      { label: 'Case Converter', id: 'case-converter' },
      { label: 'Regex Tester', id: 'regex-tester' },
      { label: 'Diff Checker', id: 'diff-checker' },
    ],
  },
  {
    title: '💻 Code Tools',
    links: [
      { label: 'JSON Formatter', id: 'json-formatter' },
      { label: 'JS Beautifier', id: 'js-beautifier' },
      { label: 'CSS Beautifier', id: 'css-beautifier' },
      { label: 'HTML Beautifier', id: 'html-beautifier' },
      { label: 'SQL Formatter', id: 'sql-formatter' },
      { label: 'SVG to JSX', id: 'svg-to-jsx' },
      { label: 'Markdown Preview', id: 'markdown' },
    ],
  },
  {
    title: '✨ Unique Tools',
    links: [
      { label: 'cURL → Fetch Converter', id: 'curl-to-fetch' },
      { label: 'Cron Expression Parser', id: 'cron-parser' },
      { label: 'Chmod Calculator', id: 'chmod-calc' },
      { label: 'CSS Specificity Calc', id: 'css-specificity' },
      { label: 'JSON Schema Generator', id: 'json-schema' },
      { label: 'HTTP Status Reference', id: 'http-status' },
      { label: 'Byte Size Calculator', id: 'byte-size' },
      { label: 'ASCII Art Generator', id: 'ascii-art' },
    ],
  },
  {
    title: '🔄 Converters',
    links: [
      { label: 'JSON to CSV', id: 'json-csv' },
      { label: 'JSON to YAML', id: 'json-yaml' },
      { label: 'Number Base Converter', id: 'number-base' },
      { label: 'Timestamp Converter', id: 'timestamp' },
      { label: 'Color Converter', id: 'color-converter' },
      { label: 'PX ↔ REM Converter', id: 'px-rem' },
    ],
  },
  {
    title: '🎨 Generators',
    links: [
      { label: 'Password Generator', id: 'password-gen' },
      { label: 'QR Code Generator', id: 'qr-code' },
      { label: 'UUID Generator', id: 'uuid' },
      { label: 'Lorem Ipsum', id: 'lorem-ipsum' },
      { label: 'CSS Gradient', id: 'gradient-gen' },
      { label: 'Box Shadow', id: 'box-shadow' },
      { label: 'Glassmorphism', id: 'glassmorphism' },
      { label: 'Favicon Generator', id: 'favicon-gen' },
    ],
  },
];

const FOOTER_STATS = [
  { value: '61+', label: 'Free Tools' },
  { value: '100%', label: 'Client-Side' },
  { value: '0s', label: 'Load Time' },
  { value: '₹0', label: 'Cost Ever' },
  { value: '0', label: 'Signups Needed' },
  { value: '∞', label: 'Uses Allowed' },
];

export default function Footer() {
  const { selectTool } = useApp();
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [feedbackVal, setFeedbackVal] = useState('');

  const handleFeedback = (e) => {
    e.preventDefault();
    if (feedbackVal.trim()) {
      // Open mailto so the suggestion actually reaches us
      const subject = encodeURIComponent('ZeroApiTools Tool Suggestion');
      const body = encodeURIComponent(`Tool Suggestion: ${feedbackVal}`);
      window.open(`mailto:feedback@webutils.app?subject=${subject}&body=${body}`);
      setFeedbackSent(true);
      setFeedbackVal('');
    }
  };

  return (
    <footer className="footer-new">


      {/* ── Main grid ── */}
      <div className="footer-main">
        {/* Brand + Feedback column */}
        <div className="footer-brand-wide">
          <div className="footer-brand-info">
            <div className="footer-logo">
              <div className="footer-logo-badge">ZA</div>
              <span className="footer-logo-name">ZeroApiTools</span>
            </div>

            <p className="footer-brand-desc">
              The all-in-one developer toolbox that runs <strong>entirely in your browser</strong>.
              No server. No API. No signup. No cost. Your data never leaves your device.
            </p>

            <div className="footer-badges">
              <span className="footer-badge">🔒 100% Private</span>
              <span className="footer-badge">⚡ Instant</span>
              <span className="footer-badge">💰 Free Forever</span>
              <span className="footer-badge">🚫 No Signup</span>
              <span className="footer-badge">📡 No Tracking</span>
            </div>
          </div>

          {/* Feedback box */}
          <div className="footer-feedback">
            <div className="footer-feedback-title">💬 Got a suggestion?</div>
            <div className="footer-feedback-sub">Tell us what tool you want next</div>
            {feedbackSent ? (
              <div className="footer-feedback-thanks">✅ Thanks! We'll consider it.</div>
            ) : (
              <form className="footer-feedback-form" onSubmit={handleFeedback}>
                <input
                  className="footer-feedback-input"
                  placeholder="e.g. TOML converter, JWT builder..."
                  value={feedbackVal}
                  onChange={e => setFeedbackVal(e.target.value)}
                  maxLength={120}
                />
                <button className="footer-feedback-btn" type="submit">Send →</button>
              </form>
            )}
          </div>

          {/* Why ZeroApiTools section */}
          <div className="footer-why">
            <div className="footer-why-title">Why ZeroApiTools?</div>
            <ul className="footer-why-list">
              <li>✅ No data sent to any server — ever</li>
              <li>✅ Lightning fast & instant load times</li>
              <li>✅ No rate limits or quotas</li>
              <li>✅ Open source, always free</li>
            </ul>
          </div>
        </div>

      </div>

      {/* ── Divider with tagline ── */}
      <div className="footer-tagline-row">
        <div className="footer-tagline">
          "Stop switching tabs. All your dev tools in one place."
        </div>
      </div>

      {/* ── Bottom bar ── */}
      <div className="footer-bottom">
        <div className="footer-bottom-left">
          <span>© {new Date().getFullYear()} <strong>ZeroApiTools</strong></span>
          <span className="footer-sep">·</span>
          <span>No data ever leaves your browser</span>
          <span className="footer-sep">·</span>
          <span>Built with <span style={{ color: '#f43f5e' }}>❤️</span> for developers</span>
          <span className="footer-sep">·</span>
          <span>{TOOLS.length} tools available</span>
        </div>
        <div className="footer-bottom-right">
          <span className="footer-status">
            <span className="status-dot" />
            All systems operational
          </span>
        </div>
      </div>
    </footer>
  );
}
