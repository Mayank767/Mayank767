import React, { useState, useMemo, useCallback, useRef, useEffect, memo } from 'react';
import { TOOLS, CATEGORIES, useApp } from '../App';

// Removed useCountUp to avoid layout thrashing

function ScrollProgress() {
  const barRef = useRef(null);
  useEffect(() => {
    const onScroll = () => {
      if (!barRef.current) return;
      const el = document.documentElement;
      const scrolled = el.scrollTop;
      const total = el.scrollHeight - el.clientHeight;
      const progress = total > 0 ? (scrolled / total) * 100 : 0;
      barRef.current.style.width = `${progress}%`;
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <div
      ref={barRef}
      style={{
        position: 'fixed', top: 0, left: 0, width: `0%`, height: 3,
        background: 'var(--gradient-purple-cyan)', zIndex: 9999,
        transition: 'width 80ms linear', borderRadius: '0 2px 2px 0',
        boxShadow: '0 0 8px rgba(16,185,129,0.6)',
      }}
    />
  );
}

export default function Landing() {
  const { selectTool, favorites, toggleFavorite, recents, usageCount } = useApp();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [viewMode, setViewMode] = useState('categories');
  const [displayedCount, setDisplayedCount] = useState(12);
  const loadMoreRef = useRef(null);

  useEffect(() => {
    if (search || activeCategory !== 'all') return;
    
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        setDisplayedCount(prev => Math.min(prev + 12, TOOLS.length));
      }
    }, { rootMargin: '400px' });
    
    if (loadMoreRef.current) observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [search, activeCategory]);

  const favoriteTools = useMemo(() => TOOLS.filter(t => favorites.includes(t.id)), [favorites]);
  const recentTools = useMemo(() => recents.slice(0, 6).map(id => TOOLS.find(t => t.id === id)).filter(Boolean), [recents]);

  const filtered = useMemo(() => {
    let results = TOOLS;
    if (activeCategory === 'favorites' && viewMode === 'tools') {
      return favoriteTools;
    }
    if (activeCategory === 'recents' && viewMode === 'tools') {
      return recentTools;
    }
    if (activeCategory !== 'all' && viewMode === 'tools') {
      results = results.filter(t => t.category === activeCategory);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      results = results.filter(t =>
        t.name.toLowerCase().includes(q) ||
        t.desc.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
      );
      return results;
    }
    return results.slice(0, displayedCount);
  }, [search, activeCategory, viewMode, displayedCount, favoriteTools, recentTools]);
  const totalUsage = Object.values(usageCount).reduce((a, b) => a + b, 0);

  return (
    <div className="landing">
      <ScrollProgress />

      {/* ── Hero ── */}
      <section className="hero">
        <div className="hero-badge">🚀 ZeroApiTools — 100% Free &amp; Open Source</div>
        <h1 className="hero-title">
          <span className="gradient-text">Developer Tools</span>
          <br />
          That Run In Your Browser
        </h1>
        <p className="hero-subtitle">
          {TOOLS.length}+ essential tools for developers — no API calls, no uploads, no cost.
          <br />
          <strong>Everything runs privately in your browser. Your data never leaves your device.</strong>
        </p>



        <div className="hero-features">
          <span className="hero-feature">🔒 100% Private</span>
          <span className="hero-feature">⚡ Instant Results</span>
          <span className="hero-feature">🚫 No Signup</span>
          <span className="hero-feature">🌐 Open Source</span>
        </div>
      </section>

      {/* ── Main Content Area ── */}
      {search || viewMode === 'tools' ? (
        <>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
            <button 
              className="btn btn-ghost" 
              onClick={() => { setViewMode('categories'); setSearch(''); setActiveCategory('all'); }}
              style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              ← Back to Categories
            </button>
            <div className="result-count" aria-live="polite" style={{ margin: 0 }}>
              {search ? (
                <><strong>{filtered.length}</strong> results for "<em>{search}</em>"</>
              ) : activeCategory === 'favorites' ? (
                <><span style={{fontSize: 20}}>⭐</span> <strong>Favorites</strong> — {filtered.length} tools</>
              ) : activeCategory === 'recents' ? (
                <><span style={{fontSize: 20}}>🕐</span> <strong>Recently Used</strong> — {filtered.length} tools</>
              ) : (
                <><span style={{fontSize: 20}}>{CATEGORIES.find(c => c.id === activeCategory)?.icon}</span> <strong>{CATEGORIES.find(c => c.id === activeCategory)?.name}</strong> — {filtered.length} tools</>
              )}
            </div>
          </div>

          {filtered.length > 0 ? (
            <>
              <div className="tools-grid">
                {filtered.map((tool, i) => (
                  <ToolCard
                    key={tool.id} tool={tool} onSelect={selectTool}
                    isFavorite={favorites.includes(tool.id)} onToggleFavorite={toggleFavorite}
                    usageCount={usageCount[tool.id] || 0} visible={true} index={i}
                  />
                ))}
              </div>
              {!search && displayedCount < TOOLS.filter(t => t.category === activeCategory).length && (
                <div ref={loadMoreRef} style={{ height: 20 }} aria-hidden="true" />
              )}
            </>
          ) : (
            <div className="no-results">
              <div className="no-results-icon">🔍</div>
              <div className="no-results-text">No tools found for "{search}"</div>
              <div className="no-results-hint">Try: json, base64, curl, chmod, cron...</div>
              <button className="btn btn-secondary" onClick={() => setSearch('')}>Clear Search</button>
            </div>
          )}
        </>
      ) : (
        <>
          <div className="section-header" style={{ marginTop: '20px' }}>
            <h2 className="section-title">📂 Browse by Category</h2>
          </div>
          <div className="tools-grid">
            {favoriteTools.length > 0 && (
              <div 
                className="category-card"
                style={{ cursor: 'pointer', animationDelay: '0ms' }}
                onClick={() => { setActiveCategory('favorites'); setViewMode('tools'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              >
                <div className="category-icon-wrapper cat-bg-amber">⭐</div>
                <h3 className="category-title">Favorites</h3>
                <p className="category-count">{favoriteTools.length} tools</p>
              </div>
            )}
            {recentTools.length > 0 && (
              <div 
                className="category-card"
                style={{ cursor: 'pointer', animationDelay: '30ms' }}
                onClick={() => { setActiveCategory('recents'); setViewMode('tools'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              >
                <div className="category-icon-wrapper cat-bg-purple">🕐</div>
                <h3 className="category-title">Recently Used</h3>
                <p className="category-count">{recentTools.length} tools</p>
              </div>
            )}
            {CATEGORIES.filter(c => c.id !== 'all').map((cat, i) => {
              const count = TOOLS.filter(t => t.category === cat.id).length;
              if (count === 0) return null;
              
              return (
                <div 
                  key={cat.id} 
                  className="category-card"
                  style={{ cursor: 'pointer', animationDelay: `${Math.min(i * 30, 300)}ms` }}
                  onClick={() => { setActiveCategory(cat.id); setViewMode('tools'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                >
                  <div className={`category-icon-wrapper cat-bg-${getCategoryColor(cat.id)}`}>{cat.icon}</div>
                  <h3 className="category-title">{cat.name}</h3>
                  <p className="category-count">{count} tools</p>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* ── Trust Bar ── */}
      <section className="trust-bar">
        <div className="trust-item">🔐 <strong>Zero Data Upload</strong> — Everything runs locally</div>
        <div className="trust-item">🚫 <strong>No Account</strong> — Start using instantly</div>
        <div className="trust-item">📡 <strong>No Tracking</strong> — No analytics on your input</div>
        <div className="trust-item">⚡ <strong>No Rate Limits</strong> — Use as much as you want</div>
      </section>
    </div>
  );
}

// ─────────────────────────────────────────
// Tool Card Component — with 3D tilt
// ─────────────────────────────────────────
const ToolCard = memo(function ToolCard({ tool, onSelect, isFavorite, onToggleFavorite, usageCount, visible, index = 0 }) {
  const cardRef = useRef(null);
  const glareRef = useRef(null);
  const rafRef = useRef(null);

  const handleMouseMove = useCallback((e) => {
    if (!cardRef.current) return;
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      const rect = cardRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const cx = rect.width / 2;
      const cy = rect.height / 2;
      const rotX = ((y - cy) / cy) * -10;
      const rotY = ((x - cx) / cx) * 10;
      const glareX = (x / rect.width) * 100;
      const glareY = (y / rect.height) * 100;
      cardRef.current.style.transform =
        `perspective(600px) rotateX(${rotX}deg) rotateY(${rotY}deg) translateZ(8px) scale(1.02)`;
      if (glareRef.current) {
        glareRef.current.style.background =
          `radial-gradient(circle at ${glareX}% ${glareY}%, rgba(255,255,255,0.12) 0%, transparent 60%)`;
        glareRef.current.style.opacity = '1';
      }
    });
  }, []);

  const handleMouseLeave = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    if (!cardRef.current) return;
    cardRef.current.style.transform = 'perspective(600px) rotateX(0deg) rotateY(0deg) translateZ(0px) scale(1)';
    if (glareRef.current) glareRef.current.style.opacity = '0';
  }, []);

  return (
    <a
      href={`/${tool.id}`}
      ref={cardRef}
      className={`tool-card tool-card-3d ${visible ? 'visible' : ''} ${tool.category === 'unique' ? 'tool-card-unique' : ''}`}
      data-id={tool.id}
      onClick={(e) => { e.preventDefault(); onSelect(tool.id); }}
      id={`tool-${tool.id}`}
      style={{ animationDelay: `${Math.min(index * 30, 300)}ms` }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      aria-label={`${tool.name} — ${tool.desc}`}
    >
      <div ref={glareRef} className="card-glare" />
      {tool.category === 'unique' && <div className="unique-badge">✨ Unique</div>}

      <div className="tool-card-top">
        <div className={`tool-card-icon ${getCategoryColor(tool.category)}`}>{tool.icon}</div>
        <button
          className={`tool-fav-btn ${isFavorite ? 'active' : ''}`}
          onClick={e => { e.preventDefault(); e.stopPropagation(); onToggleFavorite(tool.id); }}
          title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          aria-label={isFavorite ? 'Remove from favorites' : 'Save to favorites'}
        >
          {isFavorite ? '⭐' : '☆'}
        </button>
      </div>

      <h3 className="tool-card-title">{tool.name}</h3>
      <p className="tool-card-desc">{tool.desc}</p>

      <div className="tool-card-footer">
        <span className={`tool-card-tag ${tool.category}`}>{getCategoryLabel(tool.category)}</span>
        {usageCount > 0 && <span className="tool-usage-count">{usageCount}× used</span>}
      </div>
    </a>
  );
});

function getCategoryColor(cat) {
  const map = { text: 'emerald', code: 'cyan', converter: 'emerald', css: 'cyan', image: 'emerald', security: 'cyan', seo: 'emerald', unique: 'unique' };
  return map[cat] || 'emerald';
}

function getCategoryLabel(cat) {
  const map = { text: 'Text & String', code: 'Code', converter: 'Converter', css: 'CSS', image: 'Image', security: 'Security', seo: 'SEO', unique: '✨ Unique' };
  return map[cat] || cat;
}
