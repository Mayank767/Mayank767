import React, { useState, useCallback, useEffect, createContext, useContext } from 'react';
import './index.css';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Landing from './components/Landing';
import ToolFaq from './components/ToolFaq';
import { BlogList, BlogPost } from './components/blog/BlogViews';
// Text tools
const Base64Tool = React.lazy(() => import('./components/text/Base64Tool'));
const UrlEncodeTool = React.lazy(() => import('./components/text/UrlEncodeTool'));
const HtmlEntityTool = React.lazy(() => import('./components/text/HtmlEntityTool'));
const JwtDecoder = React.lazy(() => import('./components/text/JwtDecoder'));
const UuidGenerator = React.lazy(() => import('./components/text/UuidGenerator'));
const LoremIpsumGenerator = React.lazy(() => import('./components/text/LoremIpsumGenerator'));
const WordCounter = React.lazy(() => import('./components/text/WordCounter'));
const CaseConverter = React.lazy(() => import('./components/text/CaseConverter'));
const DiffChecker = React.lazy(() => import('./components/text/DiffChecker'));
const RegexTester = React.lazy(() => import('./components/text/RegexTester'));
const PrivacyPolicyGenerator = React.lazy(() => import('./components/text/PrivacyPolicyGenerator'));

// Code tools
const JsonFormatter = React.lazy(() => import('./components/code/JsonFormatter'));
const JsBeautifier = React.lazy(() => import('./components/code/JsBeautifier'));
const CssBeautifier = React.lazy(() => import('./components/code/CssBeautifier'));
const HtmlBeautifier = React.lazy(() => import('./components/code/HtmlBeautifier'));
const SqlFormatter = React.lazy(() => import('./components/code/SqlFormatter'));
const SvgToJsx = React.lazy(() => import('./components/code/SvgToJsx'));

// Converters
const JsonCsvTool = React.lazy(() => import('./components/converters/JsonCsvTool'));
const JsonYamlTool = React.lazy(() => import('./components/converters/JsonYamlTool'));
const MarkdownPreview = React.lazy(() => import('./components/converters/MarkdownPreview'));
const NumberBaseTool = React.lazy(() => import('./components/converters/NumberBaseTool'));
const TimestampTool = React.lazy(() => import('./components/converters/TimestampTool'));
const ColorConverter = React.lazy(() => import('./components/converters/ColorConverter'));
const PxRemConverter = React.lazy(() => import('./components/converters/PxRemConverter'));

// CSS Generators
const GlassmorphismGen = React.lazy(() => import('./components/css-generators/GlassmorphismGen'));
const GradientGenerator = React.lazy(() => import('./components/css-generators/GradientGenerator'));
const BoxShadowGen = React.lazy(() => import('./components/css-generators/BoxShadowGen'));
const BorderRadiusGen = React.lazy(() => import('./components/css-generators/BorderRadiusGen'));
const FlexboxPlayground = React.lazy(() => import('./components/css-generators/FlexboxPlayground'));
const CssGridGenerator = React.lazy(() => import('./components/css-generators/CssGridGenerator'));

// Image tools
const ImageCompressor = React.lazy(() => import('./components/image/ImageCompressor'));
const ImageResizer = React.lazy(() => import('./components/image/ImageResizer'));
const ImageToBase64 = React.lazy(() => import('./components/image/ImageToBase64'));
const QrCodeGenerator = React.lazy(() => import('./components/image/QrCodeGenerator'));
const PlaceholderImageGen = React.lazy(() => import('./components/image/PlaceholderImageGen'));
const ImageFormatConverter = React.lazy(() => import('./components/image/ImageFormatConverter'));
const BackgroundRemover = React.lazy(() => import('./components/image/BackgroundRemover'));

// Security
const PasswordGenerator = React.lazy(() => import('./components/security/PasswordGenerator'));
const HashGenerator = React.lazy(() => import('./components/security/HashGenerator'));

// SEO
const MetaTagGenerator = React.lazy(() => import('./components/seo/MetaTagGenerator'));
const OgPreview = React.lazy(() => import('./components/seo/OgPreview'));
const SlugGenerator = React.lazy(() => import('./components/seo/SlugGenerator'));
const FaviconGenerator = React.lazy(() => import('./components/seo/FaviconGenerator'));
const UtmBuilder = React.lazy(() => import('./components/seo/UtmBuilder'));

// Unique tools
const CurlToFetch = React.lazy(() => import('./components/unique/CurlToFetch'));
const CronParser = React.lazy(() => import('./components/unique/CronParser'));
const CssSpecificity = React.lazy(() => import('./components/unique/CssSpecificity'));
const ChmodCalculator = React.lazy(() => import('./components/unique/ChmodCalculator'));
const JsonSchemaGen = React.lazy(() => import('./components/unique/JsonSchemaGen'));
const ByteSize = React.lazy(() => import('./components/unique/ByteSize'));
const AsciiArt = React.lazy(() => import('./components/unique/AsciiArt'));
const HttpStatusRef = React.lazy(() => import('./components/unique/HttpStatusRef'));
const InstagramBioGen = React.lazy(() => import('./components/unique/InstagramBioGen'));
const HashtagGen = React.lazy(() => import('./components/unique/HashtagGen'));
const ThumbnailTextGen = React.lazy(() => import('./components/unique/ThumbnailTextGen'));

// Calculator tools
const EmiCalculator = React.lazy(() => import('./components/calculators/EmiCalculator'));
const AgeCalculator = React.lazy(() => import('./components/calculators/AgeCalculator'));
const PercentageCalculator = React.lazy(() => import('./components/calculators/PercentageCalculator'));
const GstCalculator = React.lazy(() => import('./components/calculators/GstCalculator'));
const CurrencyConverter = React.lazy(() => import('./components/calculators/CurrencyConverter'));
const SipCalculator = React.lazy(() => import('./components/calculators/SipCalculator'));
const CompoundInterestCalc = React.lazy(() => import('./components/calculators/CompoundInterestCalc'));

// PDF tools
const PdfMerge = React.lazy(() => import('./components/pdf/PdfMerge'));
const PdfSplit = React.lazy(() => import('./components/pdf/PdfSplit'));
const PdfCompress = React.lazy(() => import('./components/pdf/PdfCompress'));
const PdfPassword = React.lazy(() => import('./components/pdf/PdfPassword'));

// ─────────────────────────────────────────
// App Context — shared state across components
// ─────────────────────────────────────────
export const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

// ─────────────────────────────────────────
// TOOL REGISTRY
// ─────────────────────────────────────────
export const TOOLS = [
  // Text & String
  { id: 'base64', name: 'Base64 Encode/Decode', desc: 'Securely convert text to Base64 and back locally in your browser. 100% private.', icon: '🔤', category: 'text', component: Base64Tool, sample: 'Hello, World! 🌍' },
  { id: 'url-encode', name: 'URL Encode/Decode', desc: 'Encode & decode URL components', icon: '🔗', category: 'text', component: UrlEncodeTool, sample: 'https://example.com/search?q=hello world&lang=en' },
  { id: 'html-entity', name: 'HTML Entity Encode/Decode', desc: 'Convert HTML special characters', icon: '📄', category: 'text', component: HtmlEntityTool, sample: '<h1>Hello & "World"</h1>' },
  { id: 'jwt-decoder', name: 'JWT Decoder', desc: 'Decode JWT tokens offline. Header, payload & expiry. No server upload.', icon: '🎟️', category: 'text', component: JwtDecoder, sample: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c' },
  { id: 'uuid', name: 'UUID Generator', desc: 'Generate random v4 UUIDs in bulk', icon: '🆔', category: 'text', component: UuidGenerator, sample: '5' },
  { id: 'lorem-ipsum', name: 'Lorem Ipsum Generator', desc: 'Generate placeholder text for designs', icon: '📝', category: 'text', component: LoremIpsumGenerator, sample: '3' },
  { id: 'word-counter', name: 'Word & Character Counter', desc: 'Count words, characters, sentences & reading time', icon: '🔢', category: 'text', component: WordCounter, sample: 'The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs.' },
  { id: 'case-converter', name: 'Case Converter', desc: 'Convert text to any case — camel, snake, kebab & more', icon: '🔠', category: 'text', component: CaseConverter, sample: 'Hello World From ZeroApiTools' },
  { id: 'diff-checker', name: 'Text Diff Checker', desc: 'Compare two texts and highlight differences', icon: '📊', category: 'text', component: DiffChecker, sample: 'The quick brown fox\njumps over the lazy dog\nHello World' },
  { id: 'regex-tester', name: 'Regex Tester', desc: 'Test regular expressions with live match highlighting', icon: '🔍', category: 'text', component: RegexTester, sample: 'hello@example.com, test@gmail.com, invalid-email' },

  // Code Formatters
  { id: 'json-formatter', name: 'JSON Formatter & Validator', desc: 'Beautify, minify & validate JSON data', icon: '{ }', category: 'code', component: JsonFormatter, sample: '{"name":"John","age":30,"city":"Mumbai","skills":["JS","React","Node"]}' },
  { id: 'js-beautifier', name: 'JS Beautifier / Minifier', desc: 'Format or compress JavaScript code', icon: '⚡', category: 'code', component: JsBeautifier },
  { id: 'css-beautifier', name: 'CSS Beautifier / Minifier', desc: 'Format or compress CSS stylesheets', icon: '🎨', category: 'code', component: CssBeautifier },
  { id: 'html-beautifier', name: 'HTML Beautifier / Minifier', desc: 'Format or compress HTML markup', icon: '🌐', category: 'code', component: HtmlBeautifier },
  { id: 'sql-formatter', name: 'SQL Formatter', desc: 'Beautify SQL queries with proper indentation', icon: '🗄️', category: 'code', component: SqlFormatter, sample: 'SELECT u.id,u.name,u.email,o.total FROM users u LEFT JOIN orders o ON u.id=o.user_id WHERE u.active=1 ORDER BY o.total DESC LIMIT 10' },
  { id: 'svg-to-jsx', name: 'SVG to JSX Converter', desc: 'Convert SVG markup to React JSX syntax', icon: '⚛️', category: 'code', component: SvgToJsx },

  // Converters
  { id: 'json-csv', name: 'JSON ↔ CSV', desc: 'Convert between JSON arrays and CSV format', icon: '📋', category: 'converter', component: JsonCsvTool },
  { id: 'json-yaml', name: 'JSON ↔ YAML', desc: 'Convert between JSON and YAML format', icon: '🔄', category: 'converter', component: JsonYamlTool },
  { id: 'markdown-preview', name: 'Markdown Preview', desc: 'Write Markdown and see live rendered output', icon: '📑', category: 'converter', component: MarkdownPreview },
  { id: 'number-base', name: 'Number Base Converter', desc: 'Convert between Binary, Octal, Decimal & Hex', icon: '🔢', category: 'converter', component: NumberBaseTool },
  { id: 'timestamp', name: 'Unix Timestamp Converter', desc: 'Convert between Unix timestamps and dates', icon: '⏰', category: 'converter', component: TimestampTool },
  { id: 'color-converter', name: 'Color Converter', desc: 'Convert between HEX, RGB, HSL color formats', icon: '🎨', category: 'converter', component: ColorConverter },
  { id: 'px-rem', name: 'px ↔ rem Converter', desc: 'Convert between px and rem with custom base size', icon: '📐', category: 'converter', component: PxRemConverter },

  // CSS Generators
  { id: 'glassmorphism', name: 'Glassmorphism Generator', desc: 'Generate glass-effect CSS with live preview', icon: '🪟', category: 'css', component: GlassmorphismGen },
  { id: 'gradient', name: 'Gradient Generator', desc: 'Build linear & radial gradients visually', icon: '🌈', category: 'css', component: GradientGenerator },
  { id: 'box-shadow', name: 'Box Shadow Generator', desc: 'Design box shadows with visual editor', icon: '🔲', category: 'css', component: BoxShadowGen },
  { id: 'border-radius', name: 'Border Radius Generator', desc: 'Fine-tune all 4 corners independently', icon: '⬜', category: 'css', component: BorderRadiusGen },
  { id: 'flexbox', name: 'Flexbox Playground', desc: 'Experiment with flexbox properties visually', icon: '📦', category: 'css', component: FlexboxPlayground },
  { id: 'css-grid', name: 'CSS Grid Generator', desc: 'Build grid layouts and get the CSS code', icon: '🔳', category: 'css', component: CssGridGenerator },

  // Image Tools
  { id: 'image-compress', name: 'Image Compressor', desc: 'Compress & convert images to WebP locally in your browser without uploading to a server.', icon: '🗜️', category: 'image', component: ImageCompressor },
  { id: 'image-resize', name: 'Image Resizer', desc: 'Resize images to custom dimensions', icon: '📏', category: 'image', component: ImageResizer },
  { id: 'image-base64', name: 'Image to Base64', desc: 'Convert images to Base64 data URIs', icon: '🖼️', category: 'image', component: ImageToBase64 },
  { id: 'qr-code', name: 'QR Code Generator', desc: 'Generate QR codes from any text or URL', icon: '📱', category: 'image', component: QrCodeGenerator },
  { id: 'placeholder-image', name: 'Placeholder Image', desc: 'Generate colored placeholder images with text', icon: '🏞️', category: 'image', component: PlaceholderImageGen },

  // Security
  { id: 'password-gen', name: 'Password Generator', desc: 'Generate strong, secure passwords locally. Your passwords never leave your device.', icon: '🔐', category: 'security', component: PasswordGenerator },
  { id: 'hash-gen', name: 'Hash Generator', desc: 'Generate SHA-1, SHA-256, SHA-512 hashes', icon: '🛡️', category: 'security', component: HashGenerator },

  // SEO & Web
  { id: 'meta-tag', name: 'Meta Tag Generator', desc: 'Generate HTML meta tags for SEO', icon: '🏷️', category: 'seo', component: MetaTagGenerator },
  { id: 'og-preview', name: 'Open Graph Preview', desc: 'Preview social media sharing cards', icon: '👁️', category: 'seo', component: OgPreview },
  { id: 'slug-gen', name: 'Slug Generator', desc: 'Convert text to URL-friendly slugs', icon: '🔗', category: 'seo', component: SlugGenerator },
  { id: 'favicon-gen', name: 'Favicon Generator', desc: 'Create favicons from text or emoji', icon: '⭐', category: 'seo', component: FaviconGenerator },

  // Unique Tools
  { id: 'curl-to-fetch', name: 'cURL → Fetch Converter', desc: 'Convert cURL commands to JS fetch() or axios', icon: '🔁', category: 'unique', component: CurlToFetch, sample: "curl -X POST https://api.example.com/users -H 'Content-Type: application/json' -d '{\"name\":\"John\"}'" },
  { id: 'cron-parser', name: 'Cron Expression Parser', desc: 'Decode cron schedules in plain English + next runs', icon: '⏱️', category: 'unique', component: CronParser, sample: '0 9 * * 1-5' },
  { id: 'css-specificity', name: 'CSS Specificity Calculator', desc: 'Calculate & compare CSS selector specificity', icon: '🎯', category: 'unique', component: CssSpecificity, sample: '#main .container > p:hover' },
  { id: 'chmod-calc', name: 'Chmod Calculator', desc: 'Visual Linux file permissions calculator', icon: '🔒', category: 'unique', component: ChmodCalculator },
  { id: 'json-schema', name: 'JSON Schema Generator', desc: 'Auto-generate JSON Schema from any JSON', icon: '📐', category: 'unique', component: JsonSchemaGen, sample: '{"name":"Alice","age":28,"email":"alice@example.com","tags":["dev","react"]}' },
  { id: 'byte-size', name: 'Byte Size Calculator', desc: 'String size in UTF-8, UTF-16, UTF-32 bytes', icon: '📦', category: 'unique', component: ByteSize, sample: 'Hello, 世界! 🚀' },
  { id: 'ascii-art', name: 'ASCII Art Generator', desc: 'Convert text to ASCII art with multiple fonts', icon: '🔡', category: 'unique', component: AsciiArt, sample: 'WEB' },
  { id: 'http-status', name: 'HTTP Status Codes', desc: 'Complete reference for all HTTP status codes', icon: '📡', category: 'unique', component: HttpStatusRef },
  { id: 'instagram-bio', name: 'Instagram Bio Generator', desc: 'Generate aesthetic Instagram bios with emojis', icon: '✨', category: 'unique', component: InstagramBioGen },
  { id: 'hashtag-gen', name: 'Hashtag Generator', desc: 'Find popular and niche hashtags for social media', icon: '#️⃣', category: 'unique', component: HashtagGen, sample: 'travel' },
  { id: 'thumbnail-text', name: 'Thumbnail Text Generator', desc: 'Create catchy text overlays for video thumbnails', icon: '🖼️', category: 'unique', component: ThumbnailTextGen, sample: 'React hooks tutorial' },

  // Image (new)
  { id: 'image-format', name: 'Image Format Converter', desc: 'Convert images between JPEG, PNG, WebP formats', icon: '🔀', category: 'image', component: ImageFormatConverter },
  { id: 'bg-remover', name: 'Background Remover', desc: 'Remove image background with color-based eraser', icon: '✂️', category: 'image', component: BackgroundRemover },

  // SEO (new)
  { id: 'utm-builder', name: 'UTM Link Builder', desc: 'Build UTM tracking links for Google Analytics', icon: '📊', category: 'seo', component: UtmBuilder },

  // Text (new)
  { id: 'privacy-policy', name: 'Privacy Policy Generator', desc: 'Generate Privacy Policy & Terms of Service for your site', icon: '📋', category: 'text', component: PrivacyPolicyGenerator },

  // Calculators (new category)
  { id: 'emi-calc', name: 'EMI / Loan Calculator', desc: 'Calculate monthly EMI with full amortization schedule', icon: '🏦', category: 'calculator', component: EmiCalculator },
  { id: 'age-calc', name: 'Age Calculator', desc: 'Calculate exact age in years, months & days', icon: '🎂', category: 'calculator', component: AgeCalculator },
  { id: 'percentage-calc', name: 'Percentage Calculator', desc: 'Calculate percentages, changes & ratios instantly', icon: '💯', category: 'calculator', component: PercentageCalculator },
  { id: 'gst-calc', name: 'GST Calculator', desc: 'Add or extract GST with CGST & SGST breakdown', icon: '🧾', category: 'calculator', component: GstCalculator },
  { id: 'currency-conv', name: 'Currency Converter', desc: 'Real-time currency conversion for 20+ currencies', icon: '💱', category: 'calculator', component: CurrencyConverter },
  { id: 'sip-calc', name: 'SIP Calculator', desc: 'Calculate mutual fund SIP returns with compounding', icon: '📈', category: 'calculator', component: SipCalculator },
  { id: 'compound-interest', name: 'Compound Interest Calculator', desc: 'Calculate compound interest with yearly breakdown', icon: '💰', category: 'calculator', component: CompoundInterestCalc },

  // PDF tools (new category)
  { id: 'pdf-merge', name: 'PDF Merge', desc: 'Combine multiple PDF files into one document', icon: '📎', category: 'pdf', component: PdfMerge },
  { id: 'pdf-split', name: 'PDF Splitter', desc: 'Extract specific pages from a PDF file', icon: '✂️', category: 'pdf', component: PdfSplit },
  { id: 'pdf-compress', name: 'PDF Compressor', desc: 'Reduce PDF file size securely. 100% private, no files are uploaded to any server.', icon: '🗜️', category: 'pdf', component: PdfCompress },
  { id: 'pdf-password', name: 'PDF Password Lock', desc: 'Lock or unlock PDF files with a password', icon: '🔐', category: 'pdf', component: PdfPassword },
];

export const CATEGORIES = [
  { id: 'all', name: 'All Tools', icon: '🛠️' },
  { id: 'text', name: 'Text & String', icon: '📝' },
  { id: 'code', name: 'Code', icon: '💻' },
  { id: 'converter', name: 'Converters', icon: '🔄' },
  { id: 'calculator', name: 'Calculators', icon: '🧮' },
  { id: 'css', name: 'CSS Generators', icon: '🎨' },
  { id: 'image', name: 'Image', icon: '🖼️' },
  { id: 'pdf', name: 'PDF Tools', icon: '📄' },
  { id: 'security', name: 'Security', icon: '🔒' },
  { id: 'seo', name: 'SEO & Web', icon: '🌐' },
  { id: 'unique', name: '✨ Unique', icon: '🚀' },
];

// ─────────────────────────────────────────
// localStorage helpers
// ─────────────────────────────────────────
function lsGet(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}
function lsSet(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

// ─────────────────────────────────────────
// Main App
// ─────────────────────────────────────────
function App() {
  // Dark/Light mode
  const [darkMode, setDarkMode] = useState(() => lsGet('wu-dark', true));

  // Current tool — path-based URL routing
  const [currentTool, setCurrentTool] = useState(() => {
    const path = window.location.pathname.replace(/^\/+/, '');
    if (path === 'blog' || path.startsWith('blog-post/')) return path;
    return TOOLS.find(t => t.id === path)?.id || null;
  });

  // Favorites
  const [favorites, setFavorites] = useState(() => lsGet('wu-favorites', []));

  // Recently used (last 8)
  const [recents, setRecents] = useState(() => lsGet('wu-recents', []));

  // Usage counters
  const [usageCount, setUsageCount] = useState(() => lsGet('wu-usage', {}));

  // Toasts
  const [toasts, setToasts] = useState([]);

  // Apply dark/light mode
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
    lsSet('wu-dark', darkMode);
  }, [darkMode]);

  // Sync URL path with current tool and inject SEO tags
  useEffect(() => {
    if (currentTool === 'blog') {
      window.history.pushState(null, '', '/blog');
      document.title = 'Developer Blog - ZeroApiTools | Free Developer Tools';
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.content = 'Insights, guides, and tutorials generated for developers.';
    } else if (currentTool?.startsWith('blog-post/')) {
      window.history.pushState(null, '', `/${currentTool}`);
      document.title = 'Article - ZeroApiTools | Free Developer Tools';
    } else if (currentTool) {
      const tool = TOOLS.find(t => t.id === currentTool);
      if (tool) {
        window.history.pushState(null, '', `/${currentTool}`);
        document.title = `${tool.name} - ZeroApiTools | Free Developer Tools`;
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) metaDesc.content = tool.desc;
        const canonical = document.querySelector('link[rel="canonical"]');
        if (canonical) canonical.href = `https://zeroapitools.vercel.app/${currentTool}`;
        
        // GEO Dynamic Schema Injection
        let schemaScript = document.getElementById('geo-schema');
        if (!schemaScript) {
          schemaScript = document.createElement('script');
          schemaScript.id = 'geo-schema';
          schemaScript.type = 'application/ld+json';
          document.head.appendChild(schemaScript);
        }
        schemaScript.textContent = JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebApplication",
          "name": `${tool.name} by ZeroApiTools`,
          "url": `https://zeroapitools.vercel.app/${currentTool}`,
          "description": tool.desc,
          "applicationCategory": "DeveloperApplication",
          "operatingSystem": "Any (Web Browser)",
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
          }
        });
      }
    } else {
      window.history.pushState(null, '', '/');
      document.title = 'ZeroApiTools — 61+ Free Developer Tools';
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.content = '61+ free developer tools that run 100% in your browser. Base64, JSON formatter, image compressor, CSS generators, regex tester, cURL converter, chmod calculator and much more. No signup, no API, zero cost.';
      const canonical = document.querySelector('link[rel="canonical"]');
      if (canonical) canonical.href = 'https://zeroapitools.vercel.app/';
      
      let schemaScript = document.getElementById('geo-schema');
      if (schemaScript) {
        schemaScript.textContent = JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebApplication",
          "name": "ZeroApiTools",
          "url": "https://zeroapitools.vercel.app/",
          "description": "61+ free browser-based developer tools. No API, no uploads, 100% client-side.",
          "applicationCategory": "DeveloperApplication",
          "operatingSystem": "Any",
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
          }
        });
      }
    }
  }, [currentTool]);

  // Handle browser back/forward (popstate)
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname.replace(/^\/+/, '');
      if (path === 'blog' || path.startsWith('blog-post/')) {
        setCurrentTool(path);
      } else {
        setCurrentTool(TOOLS.find(t => t.id === path)?.id || null);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const showToast = useCallback((message, type = 'success') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);
  }, []);

  const copyToClipboard = useCallback(async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      showToast('✅ Copied to clipboard!');
    } catch {
      showToast('Failed to copy', 'error');
    }
  }, [showToast]);

  const selectTool = useCallback((toolId) => {
    setCurrentTool(toolId);
    if (toolId !== 'blog' && !toolId?.startsWith('blog-post/')) {
      // Track recents
      setRecents(prev => {
        const next = [toolId, ...prev.filter(id => id !== toolId)].slice(0, 8);
        lsSet('wu-recents', next);
        return next;
      });
      // Track usage count
      setUsageCount(prev => {
        const next = { ...prev, [toolId]: (prev[toolId] || 0) + 1 };
        lsSet('wu-usage', next);
        return next;
      });
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const goHome = useCallback(() => setCurrentTool(null), []);

  const toggleFavorite = useCallback((toolId) => {
    setFavorites(prev => {
      const next = prev.includes(toolId)
        ? prev.filter(id => id !== toolId)
        : [...prev, toolId];
      lsSet('wu-favorites', next);
      return next;
    });
  }, []);

  const shareTool = useCallback((toolId) => {
    const url = `${window.location.origin}${window.location.pathname}#tool/${toolId}`;
    copyToClipboard(url);
    showToast('🔗 Link copied! Share it with anyone.');
  }, [copyToClipboard, showToast]);

  // History per tool
  const addToHistory = useCallback((toolId, entry) => {
    const key = `wu-history-${toolId}`;
    const prev = lsGet(key, []);
    const next = [entry, ...prev.filter(e => e !== entry)].slice(0, 5);
    lsSet(key, next);
  }, []);

  const getHistory = useCallback((toolId) => {
    return lsGet(`wu-history-${toolId}`, []);
  }, []);

  const activeTool = TOOLS.find(t => t.id === currentTool);
  const ActiveComponent = activeTool?.component;
  const [sampleKey, setSampleKey] = useState(0);

  const contextValue = {
    darkMode, setDarkMode,
    favorites, toggleFavorite,
    recents, usageCount,
    selectTool, goHome,
    shareTool,
    copyToClipboard, showToast,
    addToHistory, getHistory,
  };

  return (
    <AppContext.Provider value={contextValue}>
      <Navbar currentTool={activeTool} onGoHome={goHome} onSelectTool={selectTool} />

      <main>
      {currentTool === 'blog' ? (
        <BlogList onNavigate={(page, slug) => selectTool(slug ? `blog-post/${slug}` : page)} />
      ) : currentTool?.startsWith('blog-post/') ? (
        <BlogPost slug={currentTool.replace('blog-post/', '')} onNavigate={(page, slug) => selectTool(slug ? `blog-post/${slug}` : page)} />
      ) : currentTool && ActiveComponent ? (
        <div className="tool-page animate-in">
          <div className="tool-header">
            <div className="tool-header-left">
              <h1 className="tool-title">{activeTool.icon} {activeTool.name}</h1>
              <p className="tool-description">{activeTool.desc}</p>
            </div>
            <div className="tool-header-actions">
              {activeTool.sample && (
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setSampleKey(k => k + 1)}
                  title="Load example data"
                >
                  💡 Try Example
                </button>
              )}
              <button
                className={`btn btn-ghost btn-sm favorite-btn ${favorites.includes(currentTool) ? 'active' : ''}`}
                onClick={() => toggleFavorite(currentTool)}
                title={favorites.includes(currentTool) ? 'Remove from favorites' : 'Add to favorites'}
              >
                {favorites.includes(currentTool) ? '⭐' : '☆'} {favorites.includes(currentTool) ? 'Saved' : 'Save'}
              </button>
              <button
                className="btn btn-ghost btn-sm"
                onClick={() => shareTool(currentTool)}
                title="Copy shareable link"
              >
                🔗 Share
              </button>
            </div>
          </div>
          <div className="tool-body">
            <React.Suspense fallback={<div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>Loading tool...</div>}>
              <ActiveComponent
                key={`${currentTool}-${sampleKey}`}
                copyToClipboard={copyToClipboard}
                showToast={showToast}
                addToHistory={(entry) => addToHistory(currentTool, entry)}
                getHistory={() => getHistory(currentTool)}
                sampleData={sampleKey > 0 ? activeTool.sample : undefined}
              />
            </React.Suspense>
          </div>
          <ToolFaq toolId={currentTool} />
        </div>
      ) : (
        <Landing />
      )}
      </main>

      <Footer />

      {/* Toast Container */}
      {toasts.length > 0 && (
        <div className="toast-container">
          {toasts.map(t => (
            <div key={t.id} className={`toast ${t.type}`}>
              {t.message}
            </div>
          ))}
        </div>
      )}
    </AppContext.Provider>
  );
}

export default App;
