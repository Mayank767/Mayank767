import { Client } from '@notionhq/client';

const notion = new Client({ auth: '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' });

async function updateDb() {
  try {
    const res = await notion.databases.update({
      database_id: 'd6696569-561c-4713-9055-428e3a7f3fc7',
      properties: {
        'Slug': { rich_text: {} },
        'Excerpt': { rich_text: {} },
        'Author': { rich_text: {} },
        'Status': {
          select: {
            options: [
              { name: 'Draft', color: 'gray' },
              { name: 'Published', color: 'green' }
            ]
          }
        },
        'Date': { date: {} }
      }
    });
    console.log('DB_UPDATED_SUCCESSFULLY');
  } catch (err) {
    console.error('Error updating DB:', err);
  }
}

updateDb();
