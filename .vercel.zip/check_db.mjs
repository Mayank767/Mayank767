import { Client } from '@notionhq/client';

const notion = new Client({ auth: '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' });

async function checkDb() {
  const response = await notion.databases.retrieve({ database_id: 'd6696569-561c-4713-9055-428e3a7f3fc7' });
  console.log(JSON.stringify(response.properties, null, 2));
}

checkDb();
