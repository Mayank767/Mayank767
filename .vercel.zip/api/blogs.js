import { Client } from '@notionhq/client';
import { NotionToMarkdown } from 'notion-to-md';

const notion = new Client({ auth: process.env.NOTION_API_KEY });
const n2m = new NotionToMarkdown({ notionClient: notion });

export default async function handler(req, res) {
  try {
    const databaseId = process.env.NOTION_DATABASE_ID;
    
    if (!databaseId || !process.env.NOTION_API_KEY) {
      return res.status(500).json({ error: 'Notion integration is not configured properly in Vercel Environment Variables.' });
    }

    const { slug } = req.query;

    if (slug) {
      // Fetch a single blog post by Slug
      const response = await notion.databases.query({
        database_id: databaseId,
        filter: {
          property: 'Slug',
          rich_text: {
            equals: slug,
          },
        },
      });

      if (!response.results.length) {
        return res.status(404).json({ error: 'Blog not found' });
      }

      const page = response.results[0];
      const mdblocks = await n2m.pageToMarkdown(page.id);
      const mdString = n2m.toMarkdownString(mdblocks);

      const title = page.properties.Title?.title[0]?.plain_text || page.properties.Name?.title[0]?.plain_text || 'Untitled';
      const author = page.properties.Author?.rich_text[0]?.plain_text || 'AI Agent';
      const date = page.properties.Date?.date?.start || page.created_time.split('T')[0];
      const excerpt = page.properties.Excerpt?.rich_text[0]?.plain_text || '';
      const coverImage = page.cover?.external?.url || page.cover?.file?.url || 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80';

      return res.status(200).json({
        id: page.id,
        title,
        slug,
        author,
        date,
        excerpt,
        coverImage,
        content: mdString.parent || mdString
      });

    } else {
      // Fetch all published blogs for the list
      const response = await notion.databases.query({
        database_id: databaseId,
        filter: {
          property: 'Status',
          status: {
            equals: 'Published'
          }
        },
        sorts: [
          {
            property: 'Date',
            direction: 'descending',
          },
        ],
      });

      const blogs = response.results.map((page) => {
        return {
          id: page.id,
          title: page.properties.Title?.title[0]?.plain_text || page.properties.Name?.title[0]?.plain_text || 'Untitled',
          slug: page.properties.Slug?.rich_text[0]?.plain_text || page.id,
          excerpt: page.properties.Excerpt?.rich_text[0]?.plain_text || '',
          date: page.properties.Date?.date?.start || page.created_time.split('T')[0],
          coverImage: page.cover?.external?.url || page.cover?.file?.url || 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80',
        };
      });

      return res.status(200).json(blogs);
    }
  } catch (error) {
    console.error('Notion API Error:', error);
    return res.status(500).json({ error: 'Failed to fetch blogs from Notion' });
  }
}
