async function run() {
  const response = await fetch('https://api.notion.com/v1/databases/d6696569-561c-4713-9055-428e3a7f3fc7', {
    method: 'PATCH',
    headers: {
      'Authorization': 'Bearer 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',
      'Notion-Version': '2022-06-28',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        'Slug': { rich_text: {} },
        'Excerpt': { rich_text: {} },
        'Author': { rich_text: {} },
        'Status': {
          select: {
            options: [
              { name: 'Draft', color: 'gray' },
              { name: 'Published', color: 'green' }
            ]
          }
        },
        'Date': { date: {} }
      }
    })
  });
  
  const json = await response.json();
  console.log(response.status);
  console.log(JSON.stringify(json));
}

run();
