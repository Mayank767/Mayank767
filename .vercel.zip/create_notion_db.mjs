import { Client } from '@notionhq/client';

const notion = new Client({ auth: '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' });

async function createDatabase() {
  try {
    const response = await notion.databases.create({
      parent: {
        type: 'page_id',
        page_id: '3745b8082f5e80beabc4eee1793d284f'
      },
      title: [
        {
          type: 'text',
          text: {
            content: 'ZeroApiTools Blog',
          },
        },
      ],
      properties: {
        'Title': {
          title: {},
        },
        'Slug': {
          rich_text: {},
        },
        'Excerpt': {
          rich_text: {},
        },
        'Author': {
          rich_text: {},
        },
        'Status': {
          select: {
            options: [
              { name: 'Draft', color: 'gray' },
              { name: 'Published', color: 'green' }
            ]
          }
        },
        'Date': {
          date: {}
        }
      }
    });
    console.log('DATABASE_CREATED_SUCCESSFULLY');
    console.log('DATABASE_ID:', response.id);
  } catch (error) {
    console.error('Error creating database:', error.body || error);
  }
}

createDatabase();
